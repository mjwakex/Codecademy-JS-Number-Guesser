let humanScore = 0;
let computerScore = 0;
let currentRoundNumber = 1;

let userAbs
let compAbs
// Write your code below:
 function generateTarget(){
   randomNumber = Math.floor(Math.random()*10)
   return randomNumber
 }

 function compareGuesses (user,computer,secret){
   if (user > secret){
     userAbs = user - secret
   }else if (user === secret){
     userAbs = secret
   }else{
     userAbs = secret - user
   }
    if (computer > secret){
     compAbs = computer - secret
   }else if (computer === secret){
     compAbs = secret
   }else{
     compAbs = secret - computer
   }
   if (userAbs === compAbs){
     return true
   }else if (userAbs < compAbs){
     return true
   }else{
     return false
   }
   }

   function updateScore(winner){
     if (winner === "human"){
       humanScore ++
     }else{
       computerScore ++
     }
   }

   function advanceRound(){
     currentRoundNumber ++
   }

  


